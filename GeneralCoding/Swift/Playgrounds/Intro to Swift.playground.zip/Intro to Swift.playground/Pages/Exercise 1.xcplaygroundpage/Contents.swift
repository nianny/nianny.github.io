/*
 Hallo this is my random swift code
 
 
 20 March 2021
 Swift Accelerator Program Lesson 2
 */


import UIKit

var str = "Hello, playground"
//var cuteCharacters = nil
//please dont do that

var cuteCharacters: String? = "hi"
cuteCharacters = nil


var numberOfCookies = 10
var myName = "Cookie Monster"
var amIHungery = true
var percentageEaten = 0.5

//I ate the cookies nom nom nom
numberOfCookies = 0 //I dno longer need var here to adjust it

//I don't like donuts, so lets make it constant
let numberOfDonuts = 11
//this can be useful when you are certain it is not supposed to change - if it changes there is an error

let pi = 3.1425926


//numberOfDonuts = 0
//gives error







//Exercise 1
/*
 var potatoes = 10
 var temperature: Int = 30.5
 let bananas = 20
 let name = "Mr Potato Head"
 bananas = 10
 name = 10
 potatoes = 10.99

 */

var potatoes: Double = 10
var temperature = 30.5
var bananas = 20
var name: Any = "Mr Potato Head"

bananas = 10
name = 10
potatoes = 10.99






















