var input = 12312
func findLastDigit(of input: Int){
    print("The last digit is \(input%10).")
}
findLastDigit(of: 9302849023849028)
