var x = 3
var y = 2
var boboAge = 12



func findAgeOfAhLian(years x: Int, difference y: Int, whenBoboIs boboAge: Int){
    print("Ah Lian is \((boboAge+x)*y - x) now.")
}
findAgeOfAhLian(years: 3, difference: 2, whenBoboIs: 12)
