func sumOf (_ num1: Double, and num2: Double){
    print("The first number is \(num1).")
    print("The second number is \(num2).")
    print("The sum of the two numbers is \(num1+num2).")
}

sumOf(10, and: 20)
