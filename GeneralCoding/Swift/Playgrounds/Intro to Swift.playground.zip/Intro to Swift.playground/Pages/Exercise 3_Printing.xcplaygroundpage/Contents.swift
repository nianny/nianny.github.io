//: [Previous](@previous)

import Foundation

var str = "Hello, playground"

//: [Next](@next)


//We can print text
print("Hello World")

//we can print numbers
print(5)
let c = 5
//print(c)
print(5+c)


//we can print strings
let appleCEO = "Tim Cook"
let googleCEO = "Sundar Pichai"
print("\(appleCEO) and \(googleCEO) are my best friends :)")

var numApple = 25.5
var numAndriod = 40
print("I have \(numApple) Apple phones and \(numAndriod) Andriod phones")

let name = "Nianhe [nianny]"
let className = "2I"
let ccaName = "RICO"
print("My name is \(name)")
print("My class is \(className)")
print("My CCA is \(ccaName)")
