var a = 5
var b = 20

if (a==0 || b==0){
    print("Oi, didn't i tell you no zeroes")
}
else if a%b == 0 || b%a == 0{
    print("Divisible")
}
else{
    print("Welp, indivisible")
}
