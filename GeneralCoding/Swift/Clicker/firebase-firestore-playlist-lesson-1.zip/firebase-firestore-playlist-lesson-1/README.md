# firebase-firestore-playlist
All course files for the Firebase Firestore playlist on The Net Ninja YouTube channel. 

Make sure you select the correct branch to see the files :)
