//
//  constant.swift
//  Clicker
//
//  Created by Xiao Nianhe on 31/3/21.
//

import Foundation

struct Constants {
    struct Storyboard {
        
        static let homeViewController = "HomeVC"
    }
}
